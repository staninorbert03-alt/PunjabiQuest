#!/bin/bash

# PunjabiQuest - Lokaler Test-Script
# Dieses Script hilft dir, die App lokal zu testen

echo "🧪 PunjabiQuest - Lokaler Test"
echo "================================"
echo ""

# Schritt 1: Prüfe, ob .env.local existiert
if [ ! -f .env.local ]; then
    echo "⚠️  WARNUNG: .env.local wurde nicht gefunden!"
    echo ""
    echo "Bitte erstelle eine .env.local Datei mit folgendem Inhalt:"
    echo ""
    echo "NEXT_PUBLIC_SUPABASE_URL=deine-supabase-url"
    echo "NEXT_PUBLIC_SUPABASE_ANON_KEY=dein-supabase-anon-key"
    echo ""
    echo "Möchtest du jetzt eine .env.local erstellen? (j/n)"
    read -r answer
    if [ "$answer" = "j" ] || [ "$answer" = "J" ]; then
        echo "NEXT_PUBLIC_SUPABASE_URL=https://deinprojekt.supabase.co" > .env.local
        echo "NEXT_PUBLIC_SUPABASE_ANON_KEY=dein-anon-key-hier" >> .env.local
        echo "✅ .env.local wurde erstellt!"
        echo "⚠️  WICHTIG: Bearbeite die Datei und füge deine echten Supabase-Credentials ein!"
        echo ""
        exit 0
    else
        echo "❌ Test abgebrochen. Bitte erstelle zuerst .env.local"
        exit 1
    fi
else
    echo "✅ .env.local gefunden"
fi

# Schritt 2: Prüfe, ob node_modules existiert
if [ ! -d node_modules ]; then
    echo "📦 node_modules nicht gefunden. Installiere Abhängigkeiten..."
    echo ""
    
    # Prüfe, welcher Package Manager verfügbar ist
    if command -v pnpm &> /dev/null; then
        echo "Verwende pnpm..."
        pnpm install
    elif command -v yarn &> /dev/null; then
        echo "Verwende yarn..."
        yarn install
    elif command -v npm &> /dev/null; then
        echo "Verwende npm..."
        npm install
    else
        echo "❌ Kein Package Manager gefunden! Bitte installiere Node.js und npm."
        exit 1
    fi
    
    if [ $? -eq 0 ]; then
        echo "✅ Abhängigkeiten erfolgreich installiert"
    else
        echo "❌ Fehler beim Installieren der Abhängigkeiten"
        exit 1
    fi
else
    echo "✅ node_modules gefunden"
fi

echo ""
echo "================================"
echo "🚀 Starte Entwicklungsserver..."
echo "================================"
echo ""
echo "Die App wird unter http://localhost:3000 verfügbar sein"
echo "Drücke Ctrl+C zum Beenden"
echo ""

# Schritt 3: Starte den Dev-Server
if command -v pnpm &> /dev/null; then
    pnpm dev
elif command -v yarn &> /dev/null; then
    yarn dev
else
    npm run dev
fi
