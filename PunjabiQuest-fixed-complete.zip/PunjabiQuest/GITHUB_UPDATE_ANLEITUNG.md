# 🔄 GitHub Update Anleitung - PunjabiQuest

## So aktualisierst du dein GitHub-Repository mit den Fixes

Dein aktuelles Repository auf GitHub hat noch die alten, fehlerhaften Dateien. Diese Anleitung zeigt dir, wie du die behobenen Dateien hochlädst.

---

## ⚠️ Wichtig zu wissen

**Was wurde gefixt:**
- ✅ `middleware.ts` - Migration auf @supabase/ssr
- ✅ `package.json` - Abhängigkeiten aktualisiert
- ✅ `tsconfig.json` - TypeScript-Konfiguration hinzugefügt
- ✅ `lib/supabase-client.ts` - SSR-kompatibel gemacht
- ✅ `.env.example` - Vorlage für Umgebungsvariablen

---

## 🚀 Methode 1: GitHub Web Interface (Empfohlen)

### Schritt 1: Einzelne Dateien ersetzen

1. Gehe zu deinem Repository: https://github.com/staninorbert03-alt/PunjabiQuest

2. **middleware.ts ersetzen:**
   - Klicke auf `middleware.ts`
   - Klicke auf das Stift-Symbol (Edit)
   - Lösche den gesamten Inhalt
   - Kopiere den Inhalt aus der neuen `middleware.ts` (siehe unten)
   - Commit message: "Fix: Update middleware to use @supabase/ssr"
   - Klicke auf "Commit changes"

3. **package.json ersetzen:**
   - Klicke auf `package.json`
   - Klicke auf das Stift-Symbol
   - Ersetze den Inhalt mit der neuen Version
   - Commit message: "Fix: Update dependencies"
   - Klicke auf "Commit changes"

4. **tsconfig.json hinzufügen:**
   - Gehe zur Hauptseite des Repositories
   - Klicke auf "Add file" → "Create new file"
   - Name: `tsconfig.json`
   - Füge den Inhalt ein (siehe unten)
   - Commit message: "Add TypeScript configuration"
   - Klicke auf "Commit changes"

5. **lib/supabase-client.ts ersetzen:**
   - Navigiere zu `lib/supabase-client.ts`
   - Klicke auf das Stift-Symbol
   - Ersetze den Inhalt
   - Commit message: "Fix: Update Supabase client for SSR"
   - Klicke auf "Commit changes"

### Schritt 2: Vercel neu deployen

Nach dem Update der Dateien:
1. Gehe zu deinem Vercel Dashboard
2. Der Build sollte automatisch starten
3. Warte auf "Ready" Status ✅

---

## 🚀 Methode 2: Komplettes Repository ersetzen

### Option A: Alle Dateien auf einmal hochladen

1. Gehe zu: https://github.com/staninorbert03-alt/PunjabiQuest
2. Klicke auf "Add file" → "Upload files"
3. Entpacke `PunjabiQuest-fixed.zip`
4. Ziehe **alle Dateien** in den Upload-Bereich
5. Aktiviere "Overwrite existing files"
6. Commit message: "Fix: Apply all middleware and dependency fixes"
7. Klicke auf "Commit changes"

### Option B: Git Command Line

```bash
# Navigiere zum PunjabiQuest-Ordner
cd /pfad/zu/deinem/PunjabiQuest

# Stelle sicher, dass du die neuesten Änderungen hast
git pull origin main

# Füge alle geänderten Dateien hinzu
git add middleware.ts package.json tsconfig.json lib/supabase-client.ts .env.example

# Committe die Änderungen
git commit -m "Fix: Apply middleware and dependency fixes for Vercel deployment"

# Pushe zu GitHub
git push origin main
```

---

## 📋 Wichtige Dateien zum Ersetzen

### 1. middleware.ts
```typescript
import { createServerClient, type CookieOptions } from '@supabase/ssr'
import { NextResponse, type NextRequest } from 'next/server'

export async function middleware(request: NextRequest) {
  let response = NextResponse.next({
    request: {
      headers: request.headers,
    },
  })

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return request.cookies.get(name)?.value
        },
        set(name: string, value: string, options: CookieOptions) {
          request.cookies.set({
            name,
            value,
            ...options,
          })
          response = NextResponse.next({
            request: {
              headers: request.headers,
            },
          })
          response.cookies.set({
            name,
            value,
            ...options,
          })
        },
        remove(name: string, options: CookieOptions) {
          request.cookies.set({
            name,
            value: '',
            ...options,
          })
          response = NextResponse.next({
            request: {
              headers: request.headers,
            },
          })
          response.cookies.set({
            name,
            value: '',
            ...options,
          })
        },
      },
    }
  )

  await supabase.auth.getUser()

  return response
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
}
```

### 2. package.json (Wichtige Abhängigkeiten)
Stelle sicher, dass diese Pakete in deiner `package.json` sind:

```json
{
  "dependencies": {
    "@supabase/ssr": "^0.5.2",
    "@supabase/supabase-js": "^2.45.4",
    "next": "^14.0.0",
    "react": "^18.2.0",
    "react-dom": "^18.2.0"
  },
  "devDependencies": {
    "@types/node": "^20.0.0",
    "@types/react": "^18.2.0",
    "@types/react-dom": "^18.2.0",
    "typescript": "^5.0.0"
  }
}
```

### 3. tsconfig.json (Komplett neu)
```json
{
  "compilerOptions": {
    "target": "ES2020",
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "jsx": "preserve",
    "module": "ESNext",
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "allowJs": true,
    "strict": true,
    "noEmit": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "incremental": true,
    "plugins": [
      {
        "name": "next"
      }
    ],
    "paths": {
      "@/*": ["./*"]
    }
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts"],
  "exclude": ["node_modules"]
}
```

---

## ✅ Nach dem Update

### 1. Vercel Environment Variables prüfen

Gehe zu: Vercel Dashboard → Dein Projekt → Settings → Environment Variables

Stelle sicher, dass diese gesetzt sind:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`

### 2. Build überwachen

1. Gehe zu: Vercel Dashboard → Deployments
2. Warte auf den neuen Build
3. Prüfe die Build-Logs auf Fehler

### 3. Erfolg prüfen

Der Build sollte jetzt **erfolgreich** durchlaufen mit:
- ✅ Keine Middleware-Fehler
- ✅ Keine TypeScript-Fehler
- ✅ Keine fehlenden Module
- ✅ Status: "Ready"

---

## 🐛 Troubleshooting

### "Cannot find module '@supabase/ssr'"
→ `package.json` wurde nicht richtig aktualisiert. Prüfe, ob `@supabase/ssr` in den dependencies ist.

### "process is not defined"
→ Environment Variables fehlen in Vercel. Setze `NEXT_PUBLIC_SUPABASE_URL` und `NEXT_PUBLIC_SUPABASE_ANON_KEY`.

### Build läuft immer noch fehl
→ Stelle sicher, dass **alle** Dateien ersetzt wurden, besonders `middleware.ts`.

### "Unsupported modules in Edge Function"
→ Die alte Middleware wird noch verwendet. Lösche den Vercel Build-Cache:
   - Vercel Dashboard → Settings → General → Clear Build Cache

---

## 📞 Weitere Hilfe

Wenn der Build immer noch fehlschlägt:
1. Prüfe die Build-Logs in Vercel
2. Vergleiche deine Dateien mit den oben angegebenen
3. Stelle sicher, dass `node_modules` und `.next` nicht in Git sind

---

**Viel Erfolg! 🚀**
