# 🧪 Test-Anleitung für PunjabiQuest

## Übersicht
Diese Anleitung zeigt dir, wie du die behobenen Änderungen testen kannst - sowohl lokal auf deinem Computer als auch auf Vercel.

---

## 🏠 Option 1: Lokales Testen (Empfohlen vor dem Deployment)

### Voraussetzungen
- Node.js (Version 18 oder höher)
- npm, yarn oder pnpm
- Git

### Schritt 1: Projekt lokal einrichten

```bash
# Navigiere zu deinem Projekt-Verzeichnis
cd /pfad/zu/deinem/PunjabiQuest

# Falls du die Änderungen noch nicht hast, ziehe sie von GitHub
git pull origin main

# Oder: Entpacke die ZIP-Datei an einem beliebigen Ort
```

### Schritt 2: Umgebungsvariablen einrichten

Erstelle eine `.env.local` Datei im Hauptverzeichnis:

```bash
# .env.local erstellen
touch .env.local
```

Füge folgende Zeilen hinzu (ersetze die Werte mit deinen echten Supabase-Credentials):

```env
NEXT_PUBLIC_SUPABASE_URL=https://deinprojekt.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=dein-anon-key-hier
```

**Wo finde ich diese Werte?**
1. Gehe zu [supabase.com](https://supabase.com)
2. Öffne dein Projekt
3. Klicke auf **Settings** → **API**
4. Kopiere:
   - **Project URL** → `NEXT_PUBLIC_SUPABASE_URL`
   - **anon public** Key → `NEXT_PUBLIC_SUPABASE_ANON_KEY`

### Schritt 3: Abhängigkeiten installieren

```bash
# Mit npm
npm install

# ODER mit yarn
yarn install

# ODER mit pnpm
pnpm install
```

**Was passiert hier?**
- Alle Pakete aus der `package.json` werden heruntergeladen
- Insbesondere `@supabase/ssr` und die TypeScript-Typen
- Dies kann 1-2 Minuten dauern

### Schritt 4: Entwicklungsserver starten

```bash
# Mit npm
npm run dev

# ODER mit yarn
yarn dev

# ODER mit pnpm
pnpm dev
```

**Erwartete Ausgabe:**
```
▲ Next.js 14.1.0
- Local:        http://localhost:3000
- Ready in 2.3s
```

### Schritt 5: Im Browser testen

1. Öffne deinen Browser und gehe zu: **http://localhost:3000**
2. Die App sollte ohne Fehler laden ✅

### Schritt 6: Auf Fehler prüfen

#### In der Konsole (Terminal):
- ✅ **Gut:** Keine roten Fehlermeldungen
- ❌ **Problem:** Rote Error-Meldungen → siehe Troubleshooting unten

#### Im Browser (F12 → Console):
- ✅ **Gut:** Keine roten Fehler in der Browser-Konsole
- ⚠️ **Warnung:** Gelbe Warnungen sind meist okay
- ❌ **Problem:** Rote Fehler → siehe Troubleshooting unten

### Schritt 7: Middleware testen

Die Middleware läuft bei **jedem** Seitenaufruf. Um sie zu testen:

1. Öffne die Browser-Entwicklertools (F12)
2. Gehe zum **Network** Tab
3. Lade die Seite neu (F5)
4. Prüfe die Anfragen:
   - ✅ Status 200 = Middleware funktioniert
   - ❌ Status 500 = Middleware hat einen Fehler

### Schritt 8: Authentifizierung testen (falls vorhanden)

Falls deine App Login/Registrierung hat:

1. Versuche dich einzuloggen oder zu registrieren
2. Prüfe, ob die Supabase-Verbindung funktioniert
3. ✅ **Gut:** Login funktioniert, Session wird gespeichert
4. ❌ **Problem:** Fehler beim Login → Prüfe die Umgebungsvariablen

---

## ☁️ Option 2: Auf Vercel testen (Production-Test)

### Schritt 1: Änderungen zu GitHub pushen

```bash
cd /pfad/zu/deinem/PunjabiQuest

# Status prüfen
git status

# Falls du die Änderungen noch nicht gepullt hast:
git pull origin main

# Änderungen pushen
git push origin main
```

### Schritt 2: Vercel Build beobachten

1. Gehe zu deinem **Vercel Dashboard**: https://vercel.com/dashboard
2. Wähle dein **PunjabiQuest** Projekt
3. Du siehst einen neuen Build starten (mit dem Commit "Fix: Migrate to @supabase/ssr...")

**Build-Status:**
- 🟡 **Building...** = Build läuft gerade
- ✅ **Ready** = Build erfolgreich! 🎉
- ❌ **Failed** = Build fehlgeschlagen → siehe Troubleshooting

### Schritt 3: Build-Logs prüfen

1. Klicke auf den Build
2. Scrolle durch die Logs
3. Prüfe auf Fehler:

**Gute Zeichen:**
```
✓ Compiled successfully
✓ Linting and checking validity of types
✓ Collecting page data
✓ Generating static pages
✓ Finalizing page optimization
```

**Schlechte Zeichen:**
```
✗ Type error: ...
✗ Error: Cannot find module ...
✗ The Edge Function "middleware" is referencing unsupported modules
```

### Schritt 4: Umgebungsvariablen prüfen

**Sehr wichtig!** Falls der Build erfolgreich ist, aber die App nicht funktioniert:

1. Gehe zu: **Settings** → **Environment Variables**
2. Prüfe, ob diese gesetzt sind:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
3. Falls nicht → füge sie hinzu
4. **Wichtig:** Nach dem Hinzufügen → **Redeploy** auslösen!

### Schritt 5: Live-App testen

1. Klicke auf **Visit** oder öffne deine Vercel-URL
2. Die App sollte laden ✅
3. Teste die wichtigsten Funktionen:
   - Navigation funktioniert
   - Keine 500-Fehler
   - Login/Authentifizierung (falls vorhanden)

---

## 🔍 Was genau wird getestet?

### 1. TypeScript-Kompilierung
- ✅ Alle `.ts` und `.tsx` Dateien kompilieren ohne Fehler
- ✅ Keine fehlenden Type-Definitionen
- ✅ `tsconfig.json` ist korrekt konfiguriert

### 2. Middleware (Edge Runtime)
- ✅ `middleware.ts` läuft in der Edge Runtime
- ✅ Keine Node.js-spezifischen Module werden verwendet
- ✅ Cookie-Verwaltung funktioniert korrekt
- ✅ Supabase-Session wird aktualisiert

### 3. Supabase-Integration
- ✅ Client-seitiger Supabase-Client funktioniert
- ✅ Authentifizierung läuft über die neue `@supabase/ssr` Library
- ✅ Sessions werden korrekt verwaltet

### 4. Build-Prozess
- ✅ Next.js Build läuft durch
- ✅ Alle Seiten werden generiert
- ✅ Keine fehlenden Dependencies

---

## 🐛 Troubleshooting

### Problem: "Cannot find module '@supabase/ssr'"

**Lösung:**
```bash
# Lösche node_modules und package-lock.json
rm -rf node_modules package-lock.json

# Installiere neu
npm install
```

### Problem: "process is not defined"

**Ursache:** Umgebungsvariablen fehlen

**Lösung:**
1. Prüfe, ob `.env.local` existiert (lokal)
2. Prüfe, ob Umgebungsvariablen in Vercel gesetzt sind (production)
3. Stelle sicher, dass die Variablen mit `NEXT_PUBLIC_` beginnen

### Problem: Build erfolgreich, aber App zeigt Fehler

**Lösung:**
1. Öffne Browser-Konsole (F12)
2. Prüfe auf JavaScript-Fehler
3. Häufigste Ursache: Supabase-Credentials fehlen oder sind falsch
4. Prüfe die Network-Tab auf 401/403 Fehler

### Problem: Middleware-Fehler im Vercel-Build

**Fehler:**
```
The Edge Function "middleware" is referencing unsupported modules
```

**Lösung:**
1. Stelle sicher, dass die neue `middleware.ts` verwendet wird
2. Prüfe, ob `@supabase/ssr` installiert ist (nicht `@supabase/auth-helpers-nextjs`)
3. Lösche den Vercel Build-Cache: Settings → General → Clear Cache

### Problem: TypeScript-Fehler

**Fehler:**
```
error TS2307: Cannot find module 'next/server'
```

**Lösung:**
1. Stelle sicher, dass `tsconfig.json` existiert
2. Installiere Type-Definitionen:
```bash
npm install --save-dev @types/node @types/react @types/react-dom
```

---

## ✅ Checkliste: Alles funktioniert

Hake ab, wenn diese Punkte erfüllt sind:

### Lokal:
- [ ] `npm install` läuft ohne Fehler durch
- [ ] `npm run dev` startet den Server erfolgreich
- [ ] App lädt unter http://localhost:3000
- [ ] Keine Fehler in der Terminal-Konsole
- [ ] Keine Fehler in der Browser-Konsole (F12)
- [ ] Navigation funktioniert
- [ ] Login/Authentifizierung funktioniert (falls vorhanden)

### Vercel:
- [ ] Git push erfolgreich
- [ ] Vercel Build startet automatisch
- [ ] Build-Status zeigt "Ready" ✅
- [ ] Keine Fehler in den Build-Logs
- [ ] Umgebungsvariablen sind gesetzt
- [ ] Live-App lädt ohne Fehler
- [ ] Alle Funktionen arbeiten wie erwartet

---

## 📊 Erwartete Build-Zeit

- **Lokal:** 30 Sekunden - 2 Minuten (beim ersten Mal)
- **Vercel:** 1-3 Minuten

---

## 🆘 Immer noch Probleme?

Falls nach all diesen Schritten immer noch Fehler auftreten:

1. **Kopiere die komplette Fehlermeldung** (aus Terminal oder Vercel-Logs)
2. **Mache einen Screenshot** der Browser-Konsole (F12)
3. **Teile diese Informationen** mit mir

Ich helfe dir dann bei der Fehlersuche!

---

## 🎯 Schnelltest (TL;DR)

**Lokal:**
```bash
cd PunjabiQuest
echo "NEXT_PUBLIC_SUPABASE_URL=deine-url" > .env.local
echo "NEXT_PUBLIC_SUPABASE_ANON_KEY=dein-key" >> .env.local
npm install
npm run dev
# Öffne http://localhost:3000
```

**Vercel:**
```bash
git push origin main
# Gehe zu vercel.com → Dein Projekt → Warte auf "Ready" ✅
```

---

**Viel Erfolg beim Testen! 🚀**
