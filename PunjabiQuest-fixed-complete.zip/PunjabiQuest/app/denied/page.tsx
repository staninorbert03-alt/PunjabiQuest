export default function Denied() {
  return (
    <div className="p-10 text-center text-red-400 text-2xl">
      ❌ Zugriff verweigert – Admin Rechte erforderlich.
    </div>
  );
}